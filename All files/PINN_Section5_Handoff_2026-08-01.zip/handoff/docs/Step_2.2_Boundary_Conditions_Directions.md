# Step 2.2 — Boundary Conditions, Section 5

**Days 11–12. Prerequisite: Step 2.1 complete (commit 3d67caa).**
**Deliverable:** `boundaries.py` exposing `sample_boundaries()` and `outward_normal()`,
plus `11_bc_checks.py` verifying the samplers land where they should.

---

## 0. What changed, and why it matters

The specification in your roadmap was written before two things were known. Both are
now settled, and together they change the character of the problem.

**The domain is entirely unsaturated.** The paper reports the karstic (Tm) hydraulic
head as 113–197 m a.s.l., measured in six wells screened in that unit, and states twice
that it stays below the final pit floor. Your `Z_BASE` is 200 m a.s.l. The water table
is below the *bottom of the domain*, not merely below the toe.

**So Section 5 is a rainfall-infiltration problem, not a confined-aquifer problem.**
The 20 mm/hr flux wets the marl band from above, suction is lost, effective stress
drops, and the weak zone Mk_d (σ_ci = 4.29 MPa, three-quarters of the marl band by
area) fails. Richards is genuinely needed — the SWCC and K(ψ) do real work — but there
is no uplift and no confined pressure.

Three consequences for the BC set:

| Boundary | Roadmap said | Correct |
|---|---|---|
| Pit floor, x = 0 | "ψ = 0 or no-flow, DECISION REQUIRED" | **No-flow** — above the water table, nothing to drain |
| F1 far field | "hydrostatic Dirichlet, DATUM REQUIRED" | **ψ(z) = −(z − 197)** — a suction profile |
| Cut face | "seepage face, complementarity" | Same, but **inactive at t = 0** |

---

## 1. The six segments

The domain is a quadrilateral, not a rectangle: F1 dips at 81.4°, so `x_f1(200) = 243.6`
while `x_f1(358) = 267.6`.

| # | Segment | Extent | Hydraulic | Mechanical |
|---|---|---|---|---|
| 1 | Natural ground | x 123→266 on `z_ground` | Neumann q·n = 5.56e-6 | traction-free |
| 2 | Bench | x 102→123, z ≈ 332.7 | Neumann, same | traction-free |
| 3 | Cut face | x 0→102 on `z_ground` | seepage face | traction-free |
| 4 | Pit floor | x = 0, z 200→271.1 | no-flow | roller, u = 0 |
| 5 | Base | z = 200, x 0→243.6 | no-flow | u = v = 0 |
| 6 | F1 far field | `x_f1(z)`, z 200→358 | Dirichlet ψ = −(z−197) | roller, u = 0 |

Segments 1–3 are all "the ground surface" geometrically but carry three different
conditions, which is exactly why the sampler must be stratified rather than uniform.

---

## 2. Three things that are easy to get wrong

### 2.1 The flux is q·n, not q_z

Rainfall arrives vertically, but the Neumann condition is on the flux *normal to the
boundary*. On the 31° cut face, `cos(31°) = 0.857` — a 14% error if you use the
vertical component. On the bench it makes almost no difference; on the natural ground
at 7–22° it is 1–7%.

Write `outward_normal()` once and use it everywhere. It costs nothing and removes a
whole class of silent error.

### 2.2 Sample by arc length, not by x

The cut face rises 61.6 m over 102 m of x; the bench is flat over 21 m. Uniform
sampling in x gives them point densities in proportion to their *horizontal* extent,
under-resolving the steep face by roughly 17%. Sample so that spacing is even along
the boundary itself.

### 2.3 The seepage face is not a Dirichlet condition

This is the genuinely hard boundary and the one most often mishandled. On a seepage
face, the saturated portion — where water exits and ψ = 0 — is *part of the solution*.
Above it the face is unsaturated and no water crosses. You cannot prescribe the
division in advance.

The correct statement is a complementarity condition:

```
ψ ≤ 0          (cannot support positive pressure on a free face)
q·n ≥ 0        (water may exit, never enter)
ψ·(q·n) = 0    (at each point, one or the other is zero)
```

Three ways to enforce it, in increasing order of difficulty and fidelity:

**(a) No-flow, and say so.** Exact while the face is dry, which it is at t = 0 and
until the wetting front reaches it. Simplest possible thing that could work.

**(b) Fischer–Burmeister.** Replace the three conditions with one smooth residual:

```
φ_FB(a, b) = a + b − sqrt(a² + b² + ε)     with a = −ψ, b = q·n
```

`φ_FB = 0` if and only if the complementarity holds. One residual, differentiable,
standard in contact mechanics. `ε ≈ 1e-6` keeps the gradient finite at the origin.

**(c) Full penalty on all three.** Works, but the product term `ψ·(q·n)` makes the
loss surface rough and the three penalties compete during training.

**Recommendation: start with (a), keep (b) in the file behind a flag.** Get a trained
network first. Then check whether the wetting front actually reaches the face within
your simulation horizon — if it does not, (a) was exact and there is nothing to fix.
If it does, switch the flag and retrain from the (a) checkpoint.

That sequencing matters. Debugging complementarity and PINN convergence simultaneously
is a bad position to be in, and you may find you never needed it.

---

## 3. `boundaries.py`

```python
"""
Boundary-condition samplers for Section 5, Isikdere pit.

Stratified by segment: each physical condition gets its own point set, so the
loss can weight them independently and you can verify each lands where it
should.

Units SI throughout: fluxes m/s, heads and elevations m, pressures Pa.

HYDROGEOLOGICAL CONTEXT
    Karstic (Tm) head is 113-197 m a.s.l. (Ulusay et al. 2014, Sec. 5.3, six
    wells screened in the karstic bedrock). Z_BASE = 200 m a.s.l. The water
    table therefore lies BELOW the domain: every point is unsaturated, and
    this is a rainfall-infiltration problem, not a confined-aquifer one.
"""
import numpy as np
import geometry as g

RAIN_FLUX  = 5.56e-6      # m/s, 20 mm/hr triggered case
Z_WT       = 197.0        # m a.s.l., top of the karstic head range
X_F1_BASE  = float(g.x_f1(g.Z_BASE))    # 243.6 m
Z_F1_TOP   = 358.07
X_NAT_MIN  = 123.0        # bench ends / natural ground begins

SEEPAGE_FACE_MODE = "noflow"   # "noflow" | "fischer_burmeister"


# --------------------------------------------------------------- geometry aid
def outward_normal(f, x, h=0.05):
    """Unit outward normal on an upper surface z = f(x).

    Neumann conditions are on q.n, not q_z. On the 31 deg cut face these
    differ by 14 per cent.
    """
    x = np.asarray(x, float)
    dz = (f(x + h) - f(x - h)) / (2 * h)
    nx, nz = -dz, np.ones_like(dz)
    m = np.hypot(nx, nz)
    return np.column_stack([nx / m, nz / m])


def _arclength_sample(f, x0, x1, n, rng):
    """n points on z = f(x), spaced evenly in ARC LENGTH.

    Uniform sampling in x would under-resolve the steep cut face relative to
    the flat bench by about 17 per cent.
    """
    xs = np.linspace(x0, x1, 400)
    zs = f(xs)
    s = np.concatenate([[0.0], np.cumsum(np.hypot(np.diff(xs), np.diff(zs)))])
    xq = np.interp(rng.uniform(0, s[-1], n), s, xs)
    return np.column_stack([xq, f(xq)])


# ------------------------------------------------------------------- samplers
def sample_boundaries(n=2000, seed=0):
    """Returns {segment: (N,2) array of (x, z)}.

    Counts are scaled roughly by segment length; adjust if the loss shows one
    segment dominating.
    """
    r = np.random.default_rng(seed)
    return {
        "natural_ground": _arclength_sample(g.z_ground, X_NAT_MIN, 266.0, n, r),
        "bench":          _arclength_sample(g.z_ground, g.X_CREST,
                                            g.X_BENCH_END, n // 4, r),
        "cut_face":       _arclength_sample(g.z_ground, 0.0, g.X_CREST, n, r),
        "pit_floor":      np.column_stack([np.zeros(n // 3),
                                           r.uniform(g.Z_BASE, g.Z_TOE, n // 3)]),
        "base":           np.column_stack([r.uniform(0.0, X_F1_BASE, n // 2),
                                           np.full(n // 2, g.Z_BASE)]),
        "far_field_f1":   (lambda z: np.column_stack([g.x_f1(z), z]))(
                              r.uniform(g.Z_BASE, Z_F1_TOP, n)),
    }


# ----------------------------------------------------------- hydraulic values
def psi_far_field(z):
    """Suction profile on F1, hydrostatic w.r.t. a water table at Z_WT.

    NOT a positive-pressure hydrostatic condition -- the table is below the
    domain, so psi is negative everywhere: -3 m at the base, -161 m at the top.
    """
    return -(np.asarray(z, float) - Z_WT)


def flux_bc(segment, pts):
    """Prescribed normal flux q.n (m/s) for a Neumann segment.

    Sign convention: POSITIVE = into the domain. Rainfall infiltrates, so the
    prescribed value is +RAIN_FLUX times the vertical component of the normal.
    """
    if segment in ("natural_ground", "bench"):
        nrm = outward_normal(g.z_ground, pts[:, 0])
        return RAIN_FLUX * nrm[:, 1]          # vertical rain onto a tilted face
    if segment in ("pit_floor", "base"):
        return np.zeros(len(pts))
    if segment == "cut_face" and SEEPAGE_FACE_MODE == "noflow":
        return np.zeros(len(pts))
    raise ValueError(f"{segment} is not a flux boundary in mode "
                     f"{SEEPAGE_FACE_MODE}")


def fischer_burmeister(psi, qn, eps=1e-6):
    """Smooth complementarity residual for the seepage face.

    phi(a,b) = a + b - sqrt(a^2 + b^2 + eps),  a = -psi, b = q.n
    Zero iff psi <= 0, q.n >= 0, psi*(q.n) = 0.
    Enable by setting SEEPAGE_FACE_MODE = "fischer_burmeister" -- but only
    after a working run in "noflow" mode shows the wetting front reaching the
    face. Debugging complementarity and PINN convergence at once is a bad
    place to be.
    """
    a, b = -psi, qn
    return a + b - np.sqrt(a * a + b * b + eps)


# ---------------------------------------------------------------- mechanical
def mechanical_bc(segment):
    """Displacement constraints per segment. None = traction-free."""
    return {"base":         ("fixed",  dict(u=0.0, v=0.0)),
            "far_field_f1": ("roller", dict(u=0.0)),
            "pit_floor":    ("roller", dict(u=0.0))}.get(segment)


if __name__ == "__main__":
    bc = sample_boundaries()
    for k, v in bc.items():
        print(f"  {k:<16} {len(v):>5} pts   "
              f"x {v[:,0].min():6.1f}-{v[:,0].max():6.1f}   "
              f"z {v[:,1].min():6.1f}-{v[:,1].max():6.1f}")
```

---

## 4. `11_bc_checks.py`

Do not skip this. Boundary points that drift a metre off the surface are invisible in
the loss and poison the solution quietly.

```python
"""Verify BC samplers land on their segments. Gate before Step 2.3."""
import numpy as np
import geometry as g
import boundaries as b

bc = b.sample_boundaries(2000)
ok = True

def rep(name, passed, detail=""):
    global ok
    print(f"[{'PASS' if passed else 'FAIL'}] {name:<34} {detail}")
    ok &= bool(passed)

# 1 -- surface segments lie ON the ground surface
for s in ("natural_ground", "bench", "cut_face"):
    p = bc[s]
    d = np.abs(p[:, 1] - g.z_ground(p[:, 0]))
    rep(f"{s} on surface", d.max() < 0.01, f"max dev {d.max():.2e} m")

# 2 -- segments occupy their intended x-ranges, no overlap
rng = {s: (bc[s][:,0].min(), bc[s][:,0].max())
       for s in ("cut_face", "bench", "natural_ground")}
rep("cut face x 0-102",     rng["cut_face"][1] <= g.X_CREST + 1)
rep("bench x 102-123",      rng["bench"][0] >= g.X_CREST - 1
                            and rng["bench"][1] <= g.X_BENCH_END + 1)
rep("natural ground x >123", rng["natural_ground"][0] >= b.X_NAT_MIN - 1)

# 3 -- F1 points lie on the fault trace
p = bc["far_field_f1"]
rep("F1 pts on fault", np.abs(p[:,0] - g.x_f1(p[:,1])).max() < 0.01)

# 4 -- every boundary point is on the domain edge, not inside or outside
for s, p in bc.items():
    inside = g.inside_domain(p[:,0], p[:,1] - 0.5)   # just inboard
    rep(f"{s} on domain edge", inside.mean() > 0.95,
        f"{100*inside.mean():.1f}% inboard-adjacent")

# 5 -- normals point outward (upward component positive on upper surfaces)
n = b.outward_normal(g.z_ground, bc["cut_face"][:,0])
rep("cut-face normals outward", (n[:,1] > 0).all())
cosang = n[:,1].mean()
rep("cut-face normal ~cos(31 deg)", 0.83 < cosang < 0.88, f"{cosang:.3f}")

# 6 -- far-field suction is negative everywhere (domain is unsaturated)
psi = b.psi_far_field(bc["far_field_f1"][:,1])
rep("far-field psi negative", (psi < 0).all(),
    f"{psi.min():.1f} to {psi.max():.1f} m")

print("\n" + ("ALL BC CHECKS PASSED -- proceed to Step 2.3"
              if ok else "BC CHECKS FAILED"))
```

Check 5 is the one that earns its place: `cos(31°) = 0.857`, so a mean vertical normal
component near 0.86 confirms both that the normals are correct and that the cut face
really is at 31°. It cross-validates `outward_normal()` against the geometry.

---

## 5. `12_bc_plot.py` — visual verification

```python
"""Boundary points coloured by segment. Manuscript Fig. 4."""
import matplotlib; matplotlib.use("Agg")
import numpy as np, matplotlib.pyplot as plt
import geometry as g, boundaries as b

bc = b.sample_boundaries(600)
fig, ax = plt.subplots(figsize=(12, 6))

x = np.linspace(0, 266, 500)
ax.plot(x, g.z_ground(x), "k-", lw=0.8, alpha=0.4)
ax.plot(x, g.z_tm_top(x), "k--", lw=0.8, alpha=0.4)

cols = {"natural_ground": "#2ca02c", "bench": "#8c564b",
        "cut_face": "#d62728", "pit_floor": "#1f77b4",
        "base": "#7f7f7f", "far_field_f1": "#9467bd"}
for s, p in bc.items():
    ax.scatter(p[:, 0], p[:, 1], s=6, c=cols[s], label=f"{s} ({len(p)})")

# outward normals on the cut face, every 20th point
p = bc["cut_face"][::20]
n = b.outward_normal(g.z_ground, p[:, 0])
ax.quiver(p[:, 0], p[:, 1], n[:, 0], n[:, 1], color="k",
          scale=25, width=0.002, alpha=0.6)

ax.axhline(b.Z_WT, ls=":", c="b", lw=1.2,
           label=f"karstic water table {b.Z_WT:.0f} m (below domain)")
ax.set_xlabel("x (m from toe)"); ax.set_ylabel("z (m a.s.l.)")
ax.legend(fontsize=8, ncol=2); ax.set_title("Section 5 boundary sampling")
plt.tight_layout(); plt.savefig("output/section5_boundaries.png", dpi=200)
print("written: output/section5_boundaries.png")
```

What to look for: six colours with no gaps at the joins, arrows perpendicular to the
cut face pointing away from the rock, and the water-table line sitting *below* the
whole domain — a visual reminder of why every ψ is negative.

---

## 6. Step 2.3 gets simpler

Your roadmap's Step 2.3 builds the seepage IC in two regions: suction in the
overburden above the water table, saturated pressure in the coal seam below. With the
table below `Z_BASE`, that collapses to one expression:

```python
def psi_initial(x, z):
    """t = 0 suction, hydrostatic w.r.t. the karstic table at 197 m a.s.l.
    Negative everywhere -- the whole Section 5 domain is unsaturated."""
    return -(np.asarray(z, float) - b.Z_WT)
```

Range: −3 m at the base, −168 m at the crest. Note that −168 m of suction is extreme
(≈1.6 MPa) and sits far into the dry tail of any van Genuchten SWCC. Two options:

- **Cap it** at a residual value, e.g. `max(psi, -100)`, and document the cap
- **Keep it** and accept that θ ≈ θ_r over most of the domain at t = 0

Either is defensible; the cap is kinder to training because it avoids a near-singular
K(ψ) at initialisation. Decide before Day 13 and record which.

The mechanical IC is unchanged — geostatic K₀ column — but use each unit's own ν. The
K₀ ≈ 0.39 in your roadmap is the marl value; Tm is limestone and is 87% of the domain
by area.

---

## 7. Order of work

| Day | Task |
|---|---|
| 11 | Write `boundaries.py`, run `11_bc_checks.py` until all pass |
| 11 | `12_bc_plot.py`, eyeball against `output/section5_geometry.png` |
| 12 | Mechanical BCs — `mechanical_bc()` is a stub; wire it into the loss in Phase 3 |
| 12 | Commit: `git add boundaries.py 1*.py output/ && git commit -m "Step 2.2: BC samplers"` |
| 13 | Step 2.3 ICs — decide the suction cap, write `psi_initial` and the geostatic column |

---

## 8. What to carry into Phase 3

Three facts from this step that will shape the loss function:

**Every ψ is negative.** No saturated zone at t = 0. If your trained network produces
positive pressure anywhere before rainfall has had time to infiltrate, that is a bug,
and it is worth adding as an assertion in the training loop.

**The interesting physics is the wetting front.** It advances from the top boundary
downward through 10⁻⁹ m/s marl. At that conductivity the front moves slowly — worth
estimating the penetration depth over your simulation horizon before choosing the
horizon, because if the front never reaches the Mk_d/Tm contact then the deep part of
the domain is doing nothing and can be coarsely sampled.

**The strength contrast, not the pressure, drives F = 0.94.** Mk_d at σ_ci = 4.29 MPa
against Mk at 17.9 MPa, over three-quarters of the marl band. Your SSR sweep in Phase 5
is testing whether the PINN localises shear into the weak zone correctly. That is the
mechanical analogue of the permeability contrast you will meet in Section 7, which
makes this a good first case.
