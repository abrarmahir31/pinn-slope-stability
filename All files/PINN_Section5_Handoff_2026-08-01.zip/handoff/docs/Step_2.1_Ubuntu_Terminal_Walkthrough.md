---

# Step 2.1 — Complete Ubuntu (WSL2) Terminal Walkthrough

**Environment:** `rosetta-ml` (Miniforge, inside WSL2 Ubuntu, user `abrar`)
**Interpreter:** `/home/abrar/miniforge3/envs/rosetta-ml/bin/python`
**Working folder:** `/mnt/d/Books/Thesis/My thesis/step21_geometry`
**PDF:** `/mnt/d/Books/Thesis/My thesis/j.enggeo.2014.08.005.pdf` (7,299,963 bytes)

**Deliverable:** `geometry.py` exposing `material_tag(x, z)` and `inside_domain(x, z)`
for Section 5-5′ of the Işıkdere pit, verified against the source figure.

No VS Code required. Editor is `nano`.

---

## ⚠ Read this before you type anything

**Never run `conda env update --prune` in this environment.**

Your `environment.yml` deliberately excludes PyRosetta — the header comment explains
why (date-stamped wheels, cannot be pinned). It was pip-installed separately: 1.7 GB,
with a connection timeout you had to resume through. `--prune` deletes anything present
in the environment but absent from the YAML, so it would remove PyRosetta.

Your README recommends prune as the standard update path. That advice is correct for a
YAML-complete environment and wrong for yours. Use plain `mamba install` instead.

**Two Linux habits that will bite otherwise:**
- **Paths are case-sensitive.** `My thesis` — capital M, lowercase t.
- **The space in `My thesis` must be quoted** every single time: `cd "/mnt/d/..."`.

---

# PART 0 — One-time nano configuration

Python is whitespace-sensitive and nano inserts literal tab characters by default. Mixing
tabs and spaces produces `IndentationError` or, worse, silently wrong nesting.

Fix it once:

```bash
printf 'set tabstospaces\nset tabsize 4\nset linenumbers\n' >> ~/.nanorc
```

**How to use nano** (you'll do this a dozen times below):

| Action | Keys |
|---|---|
| Open / create a file | `nano -w filename.py` |
| Paste from Windows clipboard | `Ctrl+Shift+V` (or right-click in Windows Terminal) |
| Save | `Ctrl+O`, then `Enter` |
| Exit | `Ctrl+X` |
| Save and exit in one go | `Ctrl+X`, then `y`, then `Enter` |

The `-w` flag disables line wrapping. Without it, nano can hard-wrap long code lines and
break your script.

**When pasting:** paste into an *empty* file. If you paste into a file that already has
content, check the result with `cat filename.py` before running.

---

# PART 1 — Activate and complete the environment

Open **Ubuntu** from the Start menu.

```bash
conda activate rosetta-ml
```

Your prompt should now read `(rosetta-ml) abrar@WhiteShadow:~$`.

Check what's already there:

```bash
python /mnt/d/Books/Thesis/My\ thesis/environment\ file/verify_env.py 2>/dev/null || \
  python ~/rosetta-ml/verify_env.py
```

Now install the three packages you're missing. `pandas` is commented out in your YAML's
optional block; `pymupdf` and `pillow` were never listed.

```bash
mamba install -c conda-forge pandas pymupdf pillow
```

Answer `y` when prompted. Takes 1–3 minutes.

(If `mamba: command not found`, use `conda install -c conda-forge pandas pymupdf pillow` —
same result, slower.)

Verify:

```bash
python -c "import fitz, PIL, pandas, numpy, scipy, matplotlib; print('all six ok')"
```

`fitz` is PyMuPDF's import name — that's expected, not a typo.

### Record the change

So the next machine reproduces correctly, edit the YAML:

```bash
nano -w ~/rosetta-ml/environment.yml
```

Move `pandas` out of the commented block and into the real dependency list, and add the
two new packages, so the block reads:

```yaml
dependencies:
  - python=3.10
  - pytorch-cpu          # CPU-only build of PyTorch from conda-forge
  - numpy
  - scipy
  - matplotlib
  - pandas               # ADDED: CSV loading in geometry.py
  - pymupdf              # ADDED: PDF rasterising (imports as `fitz`)
  - pillow               # ADDED: image cropping
  - pip
```

Save (`Ctrl+O`, `Enter`) and exit (`Ctrl+X`).

### ✅ Check 1
Prompt shows `(rosetta-ml)`. The six-module import prints `all six ok`.

---

# PART 2 — Navigate to the working folder

```bash
cd "/mnt/d/Books/Thesis/My thesis/step21_geometry"
ls
ls -la ../*.pdf
```

You should see `figures`, `digitised`, `output` (created earlier from Windows), and the
PDF listed at 7299963 bytes.

**Why stay on `/mnt/d` rather than copying into `~`:** WebPlotDigitizer runs in your
Windows browser and must open `section_5_5.png`; the CSVs it produces download to your
Windows Downloads folder. Working on `/mnt/d` means both Linux and Windows see the same
files with no shuttling. The 9p filesystem is slow for thousands of small files, but
you're reading one 7 MB PDF and writing a handful of PNGs — the penalty is irrelevant.

**Useful:** `explorer.exe .` opens the current directory in Windows Explorer. You'll use
this to inspect rendered figures.

### ✅ Check 2
`ls` shows the three folders; the PDF is listed at 7299963 bytes.

---

# PART 3 — Setup verification

```bash
nano -w 00_setup_check.py
```

Paste:

```python
"""Confirm the PDF is reachable and every needed package imports."""
from pathlib import Path

PDF = Path("/mnt/d/Books/Thesis/My thesis/j.enggeo.2014.08.005.pdf")

print(f"PDF exists : {PDF.exists()}")
if PDF.exists():
    print(f"Size       : {PDF.stat().st_size} bytes   (expect 7299963)")
else:
    print("  -> run:  ls ../*.pdf   and correct the path above")

print()
for mod in ["fitz", "PIL", "numpy", "scipy", "pandas", "matplotlib"]:
    try:
        __import__(mod)
        print(f"  ok      {mod}")
    except ImportError as e:
        print(f"  MISSING {mod}   ({e})")
```

Save, exit, run:

```bash
python 00_setup_check.py
```

### ✅ Check 3
`PDF exists : True`, size `7299963`, six `ok` lines.

---

# PART 4 — Find the figure page

```bash
nano -w 01_find_figure.py
```

```python
"""Locate the page containing Fig. 5 (typical cross-sections incl. 5-5')."""
import fitz

PDF = "/mnt/d/Books/Thesis/My thesis/j.enggeo.2014.08.005.pdf"

doc = fitz.open(PDF)
print(f"Total pages: {doc.page_count}\n")
print(f"{'idx':>4} {'printed':>8} {'vectors':>8} {'imgs':>5}  caption hits")
print("-" * 62)

KEYS = ["Fig. 5", "Figure 5", "5-5", "5\u20135", "Typical cross", "cross-section"]

for i, page in enumerate(doc):
    text = page.get_text()
    hits = [k for k in KEYS if k in text]
    n_vec = len(page.get_drawings())
    n_img = len(page.get_images(full=True))
    if hits or n_vec > 200:
        print(f"{i:>4} {i+1:>8} {n_vec:>8} {n_img:>5}  {hits}")

doc.close()
```

```bash
python 01_find_figure.py
```

**How to read the output.** You want the page with a `Fig. 5` caption hit **and** a high
`vectors` count — hundreds or thousands. High vector count means the figure is drawn as
line art, which rasterises cleanly at any resolution. If instead `vectors` is near zero
and `imgs` is 1, the figure is a scanned bitmap with fixed resolution; Part 5 tells you
whether it's usable.

**Write down the `idx` value** (0-based). Fig. 5 in this paper sits around index 5–8.

### ✅ Check 4
One page index noted.

---

# PART 5 — Rasterise

```bash
nano -w 02_render_page.py
```

```python
"""Rasterise the figure page at three resolutions."""
import fitz

PDF        = "/mnt/d/Books/Thesis/My thesis/j.enggeo.2014.08.005.pdf"
PAGE_INDEX = 6          # <-- EDIT: the idx from Part 4

doc = fitz.open(PDF)
page = doc[PAGE_INDEX]

for dpi in (300, 600, 1200):
    pix = page.get_pixmap(dpi=dpi)
    out = f"figures/page{PAGE_INDEX}_{dpi}dpi.png"
    pix.save(out)
    print(f"{out:<36} {pix.width:>6} x {pix.height:>6} px")

doc.close()
```

Edit `PAGE_INDEX`, save, run:

```bash
python 02_render_page.py
explorer.exe figures
```

Windows Explorer opens. Double-click the 600 dpi PNG and zoom to 300–400%.

**What you are checking:**
- Layer contacts visible as distinct lines
- Layers distinguishable by hatching or shading
- A vertical axis with **numeric elevation labels** (e.g. 300, 250, 200)
- A horizontal scale bar or distance labels

Compare 600 against 1200 dpi. If 1200 is genuinely sharper, use it throughout. If
identical, the source is bitmap-limited and 600 is your ceiling.

**If illegible even at 1200 dpi:** stop. Guessing contact positions poisons everything
downstream. Email R. Ulusay at Hacettepe University (corresponding author) for the
Section 5-5′ figure at higher resolution, or ask your library for the publisher's
original figure files. Authors are generally receptive to a student validating a new
method against their published result.

### ✅ Check 5
You can trace each contact by eye at 400% zoom and read numbers off the elevation axis.

---

# PART 6 — Crop the Section 5-5′ panel

Fig. 5 holds several cross-sections on one page. Crop tightly to just 5-5′ — more pixels
per metre means better digitising precision.

First, a grid overlay to read pixel bounds off. This is headless, so no display or `tk`
needed:

```bash
nano -w 03_find_crop.py
```

```python
"""Write a pixel-grid overlay so crop bounds can be read off by eye."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

SRC = "figures/page6_600dpi.png"        # <-- EDIT to your file

img = Image.open(SRC)
print(f"Full page: {img.width} x {img.height} px")

fig, ax = plt.subplots(figsize=(img.width / 300, img.height / 300), dpi=300)
ax.imshow(img)
step = 200
ax.set_xticks(range(0, img.width, step))
ax.set_yticks(range(0, img.height, step))
ax.grid(color="red", alpha=0.45, lw=0.5)
ax.tick_params(labelsize=3.5)
plt.setp(ax.get_xticklabels(), rotation=90)
plt.tight_layout()
plt.savefig("figures/page_with_grid.png", dpi=300)
print("written: figures/page_with_grid.png")
```

```bash
python 03_find_crop.py
explorer.exe figures
```

Open `page_with_grid.png`, find the Section 5-5′ panel, and read its bounding pixel
values off the red gridlines. Round outward to the nearest 200.

Then crop:

```bash
nano -w 04_crop_panel.py
```

```python
"""Crop the Section 5-5' panel out of the full-page render."""
from PIL import Image

SRC = "figures/page6_600dpi.png"                     # <-- EDIT
LEFT, TOP, RIGHT, BOTTOM = 300, 1200, 3400, 2100     # <-- EDIT from the grid

img = Image.open(SRC)
crop = img.crop((LEFT, TOP, RIGHT, BOTTOM))
crop.save("figures/section_5_5.png")
print(f"Cropped: {crop.width} x {crop.height} px -> figures/section_5_5.png")
```

```bash
python 04_crop_panel.py
```

Inspect, adjust the four numbers, re-run. Two or three iterations is normal.

**Critical:** the crop must contain the **elevation axis and the scale bar**. Those are
what you calibrate against. If they're cropped out, you cannot proceed.

### ✅ Check 6
`figures/section_5_5.png` shows the 5-5′ section with its elevation axis and scale bar.

---

# PART 7 — Digitise (Windows browser)

Leave the terminal. Open your Windows browser and search **"WebPlotDigitizer automeris"**.
Use the web app — nothing is uploaded, it runs locally in the browser.

The file you need is at this Windows path:

```
D:\Books\Thesis\My thesis\step21_geometry\figures\section_5_5.png
```

### 7.1 Load

**File → Load Image** (or drag the PNG in). Plot type: **2D (X-Y) Plot**. Click
**Align Axes**.

### 7.2 Calibrate

Four clicks — two for X, two for Y.

**Y (vertical):** click two *labelled elevation ticks* on the section's own elevation
axis, e.g. the `300` tick then the `200` tick. Enter `300` and `200` as their values.

**X (horizontal):** cross-sections usually have no labelled X axis, only a scale bar.
Click the two ends of the scale bar. If it reads "0 — 200 m", enter `0` and `200`. Your
x-origin will be arbitrary; `geometry.py` shifts it to the pit toe automatically.

Leave **log scale unchecked** on both. Click **Calibrate**.

### 7.3 ⚠ The 30° test — do not skip

**This is the most important check in Step 2.1. Do not proceed to 7.4 until it passes.**

Switch to **Manual Extract**. Click exactly two points on the pit face: one at the crest,
one at the toe. Open **View Data**, read their coordinates, and compute:

```
angle = atan( (z_crest − z_toe) / (x_toe − x_crest) )   in degrees
```

**Expected: 30° ± 1°** — the initial project's overall pit wall angle, per the paper.

| You measure | Meaning | Action |
|---|---|---|
| ~30° | Correct | Delete the two test points, continue |
| ~49° | ≈2× vertical exaggeration missed, or wrong Y ticks | **Re-calibrate.** Check the figure for a "V.E. = 2x" annotation |
| ~17° | Exaggeration the other way, or wrong ticks | **Re-calibrate** |

Why this matters more than any other step: wrong vertical calibration scales every
elevation by a constant factor. Nothing downstream errors. Tags populate, checks mostly
pass, the PINN trains happily — and returns a factor of safety 20% off with no
diagnostic pointing back here. You'd spend a week debugging the network.

### 7.4 Extract six datasets

**Dataset dropdown → Add Dataset** for each, then click along the contact.

| Dataset name | What to click | Care | Why it matters |
|---|---|---|---|
| `ground` | Ground topography | Medium | Rainfall flux boundary; overburden weight |
| `debris_base` | Base of slope debris | Medium | Thin (2–12 m), shallow influence only |
| `weak_base` | Base of weak zone — **see note** | **High** | σ_ci 4.29 vs 17.9 MPa; compound surfaces run through it |
| `coal_top` | Sekköy marl base = coal roof | **Highest** | K jumps 10⁻⁹→10⁻⁶ m/s; γ drops 14.9→8.6 kN/m³; anchors the 205 m confined head |
| `underclay_top` | Coal base = underclay top | **High** | Weak plastic clay; a known failure path (F = 0.82 in section 2) |
| `pit_face` | The overall 30° ramp | **High** | Defines the excavation |

**`weak_base` note:** the paper describes the weak zone as restricted to the northern pit,
reaching down to about +280 m — it is **not** a continuous layer. Look at the figure and
determine whether it spans all of Section 5-5′ or only part of the width. **Write down
the x-range where it exists.** If absent entirely, skip the dataset — Part 8 handles both.

**`pit_face` note:** click the **overall ramp**, not the bench sawtooth. The paper's LEM
used overall profiles for design sections. Bench detail (7–10 m benches, 60° faces) sits
far below your collocation spacing, and adding it moves you *away* from comparability
with F = 0.94. Two to four points on the straight ramp suffices.

**Technique:** dense points where the contact curves, sparse on straight runs. 20–40 per
surface. Zoom the browser with `Ctrl +` when contacts crowd. Delete Point tool for
misclicks.

### 7.5 Export

For **each** dataset: **View Data → Download .CSV**. They land in your Windows Downloads
folder.

> **If your version of WebPlotDigitizer only offers a combined export** (one CSV holding
> all datasets as side-by-side column pairs), that's fine — Part 8 includes a splitter.

### ✅ Check 7
Six CSVs in Windows Downloads, and the 30° test passed.

---

# PART 8 — Move the CSVs into place

Back in Ubuntu. Find your Windows username:

```bash
ls /mnt/c/Users/
```

Then, substituting it:

```bash
WINUSER=abrar                      # <-- EDIT to match the ls output
ls -la "/mnt/c/Users/$WINUSER/Downloads"/*.csv
```

Inspect the filenames. WebPlotDigitizer names exports inconsistently across versions
(`wpd_dataset.csv`, `Default Dataset.csv`, `Dataset 1.csv`…), so rename explicitly as you
move them:

```bash
cd "/mnt/d/Books/Thesis/My thesis/step21_geometry"
DL="/mnt/c/Users/$WINUSER/Downloads"

mv "$DL/<whatever the ground file is called>.csv"        digitised/ground.csv
mv "$DL/<...>.csv"                                       digitised/debris_base.csv
mv "$DL/<...>.csv"                                       digitised/weak_base.csv
mv "$DL/<...>.csv"                                       digitised/coal_top.csv
mv "$DL/<...>.csv"                                       digitised/underclay_top.csv
mv "$DL/<...>.csv"                                       digitised/pit_face.csv

ls -la digitised/
head -3 digitised/coal_top.csv
```

The final names must be **exactly** as shown — `geometry.py` looks them up by name.

`head -3` shows you the format: two comma-separated columns, possibly with a header row.
The loader handles either.

### If you got a single combined CSV instead

```bash
nano -w 04b_split_csv.py
```

```python
"""Split a combined WebPlotDigitizer export into one CSV per dataset."""
import pandas as pd

SRC = "digitised/wpd_datasets.csv"    # <-- EDIT to the downloaded filename
# Order must match the dataset order in WebPlotDigitizer:
NAMES = ["ground", "debris_base", "weak_base",
         "coal_top", "underclay_top", "pit_face"]

raw = pd.read_csv(SRC, header=None, skiprows=2)   # 2 header rows in WPD exports
for i, name in enumerate(NAMES):
    pair = raw.iloc[:, 2 * i:2 * i + 2].apply(pd.to_numeric, errors="coerce").dropna()
    pair.to_csv(f"digitised/{name}.csv", header=False, index=False)
    print(f"{name:<16} {len(pair):>4} points")
```

Adjust `skiprows` if `head -5` on the source shows a different number of header lines.

### ✅ Check 8
`ls digitised/` shows the correctly-named CSVs, each with numeric content.

---

# PART 9 — Build `geometry.py`

```bash
nano -w geometry.py
```

```python
"""
Section 5-5' domain geometry, Isikdere lignite pit (Ulusay et al., 2014).

COORDINATE SYSTEM
    x : metres, horizontal, x = 0 at the pit toe, increasing into the far field
    z : metres above sea level (m a.s.l.)
    Plane-strain idealisation, matching the 2-D LEM of the source paper.

PROVENANCE
    Fig. 5, Section 5-5', rendered at 600 dpi from the publisher PDF and
    digitised in WebPlotDigitizer. Vertical calibration verified by the
    30-degree pit-face test.

VALIDATION TARGET
    The paper reports F = 0.94 for a non-circular compound surface through the
    overburden, following a bedding plane in the Sekkoy marl, at the initial
    30-degree overall pit wall angle.
"""
import numpy as np
import pandas as pd
from scipy.interpolate import PchipInterpolator
from pathlib import Path

DIG = Path(__file__).parent / "digitised"

# --------------------------------------------------------------- loading
def load_contact(name):
    """Read a WebPlotDigitizer CSV -> (x, z) arrays, sorted, deduplicated."""
    df = pd.read_csv(DIG / f"{name}.csv", header=None, names=["x", "z"])
    df = df.apply(pd.to_numeric, errors="coerce").dropna()   # drops header row
    df = df.sort_values("x").drop_duplicates("x")
    if len(df) < 2:
        raise ValueError(f"{name}.csv has fewer than 2 usable points")
    return df["x"].to_numpy(), df["z"].to_numpy()

# ------------------------------------------------ x-origin at the pit toe
_xf, _zf = load_contact("pit_face")
X_TOE = float(_xf[np.argmin(_zf)])       # lowest pit-face point = the toe

def _interp(name):
    x, z = load_contact(name)
    return PchipInterpolator(x - X_TOE, z, extrapolate=True)

# PCHIP, not CubicSpline. A cubic spline overshoots between digitised points
# and can lift the coal roof above the marl base, creating an impossible
# geometry that corrupts material tags with no error message.

z_ground        = _interp("ground")
z_debris_base   = _interp("debris_base")
z_coal_top      = _interp("coal_top")
z_underclay_top = _interp("underclay_top")
z_pit_face      = _interp("pit_face")

# ------------------------------------------------------------- weak zone
# Restricted to part of the northern pit, down to about +280 m a.s.l.
HAS_WEAK_ZONE = True
WEAK_X_MIN, WEAK_X_MAX = 0.0, 150.0      # <-- EDIT from Part 7.4

if HAS_WEAK_ZONE:
    z_weak_base = _interp("weak_base")
else:
    z_weak_base = lambda x: np.full_like(np.asarray(x, float), -1e9)

# ------------------------------------------------------------- constants
Z_BASE = 40.0    # m a.s.l. Domain base. At least one slope height below the
                 # pit floor (~+170 m) so the fixed bottom BC and no-flow
                 # condition do not perturb the region of interest.
                 # NOTE: the "170 m" in the roadmap is PIT DEPTH, not domain
                 # height. The domain is taller than 170 m.

X_MIN, X_MAX = 0.0, 400.0

# ------------------------------------------------------------ predicates
def inside_domain(x, z):
    """True where (x, z) is solid ground: below topography, behind the pit
    face, above the domain base. Excludes the excavated void."""
    x = np.asarray(x, float); z = np.asarray(z, float)
    return (z <= z_ground(x)) & (z >= Z_BASE) & (z <= z_pit_face(x))

def material_tag(x, z):
    """Stratum label at (x, z). Vectorised over arrays.

    Top-down comparison chain rather than polygon containment: it vectorises
    to millions of points in milliseconds, makes the stacking order explicit,
    and cannot produce gaps or slivers at the contacts -- which is exactly
    where independently-built polygons disagree.
    """
    x = np.asarray(x, float); z = np.asarray(z, float)
    in_weak = ((x >= WEAK_X_MIN) & (x <= WEAK_X_MAX)
               & (z > z_weak_base(x)) & (z <= z_debris_base(x)))
    return np.select(
        [~inside_domain(x, z),
         z > z_debris_base(x),
         in_weak,
         z > z_coal_top(x),
         z > z_underclay_top(x)],
        ["outside", "debris", "weak_zone", "marl", "coal"],
        default="underclay",
    )

# -------------------------------- property lookup (from Step 1.1 SI sheet)
# VERIFY every value against your own conversion sheet before trusting these.
K_S = {"debris":    1.0e-6,     # m/s
       "weak_zone": 1.0e-9,
       "marl":      1.0e-9,     # assumed aquitard value, ~0 Lugeon
       "coal":      3.5e-6,     # mid-range of 1.16e-6 to 5.79e-6
       "underclay": 1.0e-9}

RHO = {"debris":    1794.0,     # kg/m3
       "weak_zone": 1723.0,
       "marl":      1519.0,
       "coal":       877.0,
       "underclay": 1876.0}

# Residual Mohr-Coulomb, design-governing (paper Table 3a)
C_RES   = {"marl": 4.4e3, "underclay": 13.6e3, "debris": 8.0e3,
           "coal": 4.4e3, "weak_zone": 4.4e3}          # Pa
PHI_RES = {"marl": 15.4, "underclay": 13.1, "debris": 15.8,
           "coal": 15.4, "weak_zone": 15.4}            # degrees

CONFINED_HEAD_COAL = 205.0     # m a.s.l., feeds Step 2.3
```

**Two things you must edit:** `WEAK_X_MIN` / `WEAK_X_MAX` from Part 7.4, and
`HAS_WEAK_ZONE = False` if the zone is absent from this section.

**Verify `K_S`, `RHO`, `C_RES`, `PHI_RES`** against your own Step 1.1 conversion sheet.
These are transcribed from it, but a transcription error here propagates into every
residual you compute for the rest of the project.

```bash
python -c "import geometry; print('imports cleanly')"
```

### ✅ Check 9
Imports without error.

---

# PART 10 — Acceptance checks

```bash
nano -w 05_checks.py
```

```python
"""Gate before Step 2.2. All six checks must pass."""
import numpy as np
import geometry as g

x = np.linspace(g.X_MIN, g.X_MAX, 2001)
ok = True

def report(name, passed, detail=""):
    global ok
    print(f"[{'PASS' if passed else 'FAIL'}] {name:<34} {detail}")
    ok &= bool(passed)

# 1 -- stratigraphic ordering
order = ((g.z_ground(x) >= g.z_debris_base(x))
         & (g.z_debris_base(x) >= g.z_coal_top(x))
         & (g.z_coal_top(x) >= g.z_underclay_top(x))
         & (g.z_underclay_top(x) >= g.Z_BASE))
report("stratigraphic ordering", order.all(), f"{(~order).sum()} violations")

# 2 -- coal seam thickness 1-30 m (paper section 4)
t = g.z_coal_top(x) - g.z_underclay_top(x)
report("coal thickness 1-30 m", t.min() >= 1 and t.max() <= 30,
       f"range {t.min():.1f}-{t.max():.1f} m")

# 3 -- pit face angle 30 deg (vertical-exaggeration check, closed)
zf = g.z_pit_face(x)
sel = zf < zf.max() - 1e-6
slope = np.polyfit(x[sel], zf[sel], 1)[0]
ang = abs(np.degrees(np.arctan(slope)))
report("pit face angle 30 deg", 29 <= ang <= 31, f"{ang:.1f} deg")

# 4 -- coal roof at or below the 205 m confined head
report("coal roof <= 205 m a.s.l.", g.z_coal_top(x).max() <= 205.5,
       f"max {g.z_coal_top(x).max():.1f} m")

# 5 -- no unassigned interior points
X, Z = np.meshgrid(x[::8], np.linspace(g.Z_BASE, 380, 400))
tag = g.material_tag(X, Z)
report("all interior points tagged",
       not np.any((tag == "outside") & g.inside_domain(X, Z)))

# 6 -- properties exist for every stratum present
present = set(np.unique(tag)) - {"outside"}
report("properties defined", present <= set(g.K_S) & set(g.RHO),
       f"{sorted(present)}")

print("\n" + ("ALL CHECKS PASSED -- proceed to Step 2.2"
              if ok else "CHECKS FAILED -- do not proceed"))
```

```bash
python 05_checks.py
```

### Diagnosing failures

| Failure | Cause | Fix |
|---|---|---|
| Pit face ≈ 49° | Vertical exaggeration | Re-calibrate (Part 7.2–7.3) |
| Coal thickness > 30 m | Wrong contact for `underclay_top` | Re-digitise that surface |
| Ordering violations | Contacts cross | `cat digitised/*.csv` — look for outlier points from misclicks |
| Coal roof > 205 m | Y calibration offset, or wrong `coal_top` | Re-check which elevation ticks you used |
| Unassigned interior points | `Z_BASE` too high, or weak-zone x-range wrong | Adjust constants in `geometry.py` |

### ✅ Check 10
`ALL CHECKS PASSED`.

---

# PART 11 — Visual verification

The numerical checks cannot catch a contact traced one layer too high — that passes
everything in Part 10 while being completely wrong. Only the overlay catches it.

```bash
nano -w 06_overlay.py
```

```python
"""Digitised contacts + material tags. Becomes manuscript Fig. 3."""
import matplotlib
matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt
import geometry as g

x = np.linspace(g.X_MIN, g.X_MAX, 800)
fig, (a1, a2) = plt.subplots(2, 1, figsize=(11, 10), sharex=True)

for fn, lab in [(g.z_ground,        "ground surface"),
                (g.z_debris_base,   "debris base"),
                (g.z_coal_top,      "coal seam roof"),
                (g.z_underclay_top, "underclay top"),
                (g.z_pit_face,      "pit face (30 deg)")]:
    a1.plot(x, fn(x), lw=1.7, label=lab)
if g.HAS_WEAK_ZONE:
    xw = x[(x >= g.WEAK_X_MIN) & (x <= g.WEAK_X_MAX)]
    a1.plot(xw, g.z_weak_base(xw), lw=1.7, ls=":", label="weak zone base")
a1.axhline(g.CONFINED_HEAD_COAL, ls="--", c="k", lw=0.9,
           label=f"confined head {g.CONFINED_HEAD_COAL:.0f} m a.s.l.")
a1.axhline(g.Z_BASE, ls="-", c="0.6", lw=0.9, label="domain base")
a1.set_ylabel("z (m a.s.l.)"); a1.legend(fontsize=8, ncol=2)
a1.set_title("Section 5-5' digitised contacts")

rng = np.random.default_rng(0)
px = rng.uniform(g.X_MIN, g.X_MAX, 60000)
pz = rng.uniform(g.Z_BASE, 380, 60000)
tag = g.material_tag(px, pz)
for name, col in [("debris", "#8c6d3f"), ("weak_zone", "#c46a4a"),
                  ("marl", "#7d94a8"), ("coal", "#1e1e1e"),
                  ("underclay", "#a8956b")]:
    m = tag == name
    if m.any():
        a2.scatter(px[m], pz[m], s=1.4, c=col, label=f"{name} (n={m.sum()})")
a2.set_xlabel("x (m from pit toe)"); a2.set_ylabel("z (m a.s.l.)")
a2.legend(fontsize=8, markerscale=6)
a2.set_title("Material tags on a random collocation cloud")

plt.tight_layout()
plt.savefig("output/section_5_5_geometry.png", dpi=200)
print("written: output/section_5_5_geometry.png")
```

```bash
python 06_overlay.py
explorer.exe output
```

Open the result alongside `figures/section_5_5.png` and compare:

- Do the digitised contacts sit on the printed ones?
- Panel 2: clean bands, no slivers at contacts, no points in the excavated void?
- Is the coal band thin and dark, sitting just below 205 m?

### ✅ Check 11
The overlay matches the source figure. This plot becomes manuscript Figure 3.

---

# PART 12 — Wrap up

```bash
ls -R
```

Expected:

```
geometry.py                         <- Step 2.2 imports this
digitised/*.csv                     <- raw digitisation, keep for provenance
figures/section_5_5.png             <- the source you digitised from
output/section_5_5_geometry.png     <- verification plot / Fig. 3
00_setup_check.py ... 06_overlay.py <- reproducible pipeline
```

Commit everything, CSVs included. In eight months a reviewer will ask how you obtained
the geometry; the CSVs plus the `geometry.py` docstring are the answer.

### What this feeds forward

| Output | Consumed by |
|---|---|
| `inside_domain(x, z)` | Step 3.2 collocation sampling |
| `material_tag(x, z)` + property dicts | PDE residuals in `L_PDE`; Phase 5 SSR sweeps |
| Boundary polylines | Step 2.2 stratified BC samplers |
| `z_coal_top`, `CONFINED_HEAD_COAL` | Step 2.3 initial pore-pressure state |
| Contact elevations | Step 2.3 geostatic K₀ column |

---

# PART 13 — Recommended: digitisation sensitivity

Ten minutes, and it tells you whether F = 0.94 is validatable at your precision.

```bash
nano -w 07_sensitivity.py
```

```python
import numpy as np, geometry as g
x = np.linspace(0, 400, 500)
for dz in (-2.0, 0.0, +2.0):
    t = (g.z_coal_top(x) + dz) - g.z_underclay_top(x)
    print(f"dz = {dz:+.1f} m -> coal thickness {t.min():.1f}-{t.max():.1f} m")
    # then recompute F with your chosen stability method
```

Perturb the coal roof by ±2 m — roughly your digitisation precision — and see how the
factor of safety responds. If F moves ~0.02, your precision is adequate. If it moves
~0.15, the case is more geometry-sensitive than your data supports. That is a real
finding, and far better discovered on Day 14 than in peer review.

Trivial with scripted geometry, effectively impossible in a GUI package — the strongest
argument for building the pipeline this way regardless of which LEM software you
eventually get running.

---

# Appendix A — Every command in order

```bash
# --- one-time
printf 'set tabstospaces\nset tabsize 4\nset linenumbers\n' >> ~/.nanorc

# --- every session
conda activate rosetta-ml
cd "/mnt/d/Books/Thesis/My thesis/step21_geometry"

# --- Part 1 (once)
mamba install -c conda-forge pandas pymupdf pillow
python -c "import fitz, PIL, pandas, numpy, scipy, matplotlib; print('all six ok')"

# --- Parts 3-6
python 00_setup_check.py      # PDF found, imports ok
python 01_find_figure.py      # note the page idx
python 02_render_page.py      # edit PAGE_INDEX first
explorer.exe figures          # inspect legibility
python 03_find_crop.py        # grid overlay
python 04_crop_panel.py       # edit bounds, iterate

# --- Part 7: Windows browser, WebPlotDigitizer
#     calibrate -> VERIFY 30 deg -> export 6 CSVs

# --- Parts 8-11
ls /mnt/c/Users/                                  # find WINUSER
ls -la "/mnt/c/Users/$WINUSER/Downloads"/*.csv
# mv each into digitised/ with the exact required name
python 05_checks.py           # must print ALL CHECKS PASSED
python 06_overlay.py
explorer.exe output
```

# Appendix B — Ubuntu quick reference

| Task | Command |
|---|---|
| Open a folder in Windows Explorer | `explorer.exe .` |
| Convert a Windows path to Linux | `wslpath "D:\Books\Thesis"` |
| Windows D: drive | `/mnt/d/` |
| Windows Downloads | `/mnt/c/Users/<user>/Downloads` |
| Edit a file | `nano -w file.py` |
| Save / exit nano | `Ctrl+O`, `Enter` / `Ctrl+X` |
| View a file | `cat file.py` or `less file.py` |
| Environment interpreter path | `/home/abrar/miniforge3/envs/rosetta-ml/bin/python` |
| Paste into terminal | `Ctrl+Shift+V` |
