# PINN Slope Stability — Session Handoff

**Project:** Physics-Informed Neural Network for coupled hydro-mechanical slope
stability, Işıkdere lignite open pit, validated against Ulusay, Ekmekçi, Tuncay &
Hasançebi (2014), *Engineering Geology* 181, 261–280.

**Session date:** 1 August 2026
**Status:** Phase 2 Steps 2.1 and 2.2 COMPLETE and committed. **Resume at Step 2.3.**

**Machine:** WSL2 Ubuntu 26.04, conda env `rosetta-ml` (Python 3.10, pytorch-cpu,
numpy, scipy, pandas, matplotlib, pymupdf, pillow).
**Working folder:** `/mnt/d/Books/Thesis/My thesis/step21_geometry`
**Git:** repo at `/mnt/d/Books/Thesis/My thesis`, branch `main`, local only —
**no remote yet, this is the standing risk.**

---

## 1. Read this first: what the earlier plan got wrong

The roadmap and the 60/15-day workflow were written against the wrong figure. Three
corrections propagate through everything downstream.

**The F = 0.94 geometry is Fig. 19d, not Fig. 5b.** Fig. 5b is the *pre-mining*
geological cross-section — natural hillside, no pit face, 1430 m wide. Fig. 19d is the
remedial-measures figure and carries the excavated 31° wall that produces F = 0.94.

**Section 5 contains no coal seam, no underclay, and no confined aquifer.** The
roadmap's "underclay/Turgut, coal seam, Sekköy marl, ≈400 × 170 m" describes Section 7,
not Section 5. The actual strata are Tm / Mk / Mk_d. Ly (coal) sits 50–80 m *below* the
domain floor.

**The domain is entirely unsaturated.** The karstic (Tm) hydraulic head is 113–197 m
a.s.l. (six wells, paper §5.3), and `Z_BASE` is 200 m a.s.l. The water table lies below
the *bottom of the domain*. Section 5 is a rainfall-infiltration problem, not a
confined-aquifer one. The original Step 2.3 initial condition — confined head
h₀ = 205 m a.s.l. in the coal seam — refers to a unit that is not present and an
elevation below the domain floor.

The original BC and IC lists are **correct for Section 7** and are preserved as
"Step 2.2b, deferred" in the corrected workflow document.

---

## 2. Unit identities, fixed by the Fig. 19 caption

The paper's own caption settles labels that were guessed at earlier:

> *Ym: slope debris, Gkçt: lacustrine limestone of the Sekköy formation, **Mk_d: weak
> zone in the Sekköy formation**, Mk: marl of the Sekköy formation, Ly: lignite (coal
> seam), Ksk: underclay, **Tm: crystallized basement limestone***

| Label | Unit | Role | In Section 5? |
|---|---|---|---|
| **Tm** | Crystallized basement limestone (Mesozoic) | **karstic AQUIFER** | yes, 87% by area |
| **Mk** | Marl of the Sekköy Fm. | aquiclude | yes, x < 90.7 m |
| **Mk_d** | **WEAK ZONE** in the Sekköy Fm. | aquiclude | yes, x > 90.7 m |
| Ly | Lignite coal seam | aquifer | no — 50–80 m below |
| Ksk | Underclay | aquiclude | no |
| Gkçt, Yt, Ym, Al | limnic ls., tuffite, debris, alluvium | — | no |

**Note the inverted hydrogeology:** the aquifer (Tm) is at the BASE, overlain by two
aquicludes. This is the reverse of Section 7, where the coal aquifer is sandwiched.

**Mk_d is the weak zone**, not a "deformed member" — that was a guess made before the
caption was found. σ_ci = 4.29 MPa against Mk's 17.9 MPa, and it is ~76% of the marl
band by area. It probably governs F = 0.94.

**An apparent contradiction, resolved:** Fig. 5b shows Tm as a thin band *above* Mk
near F1, while Fig. 19d has it as the bulk mass *below*. This is fault juxtaposition —
F1 is the northern boundary fault and has thrown the basement up against the Neogene
sequence. Same unit, two structural positions. The material tags are correct.

---

## 3. Geometry established (Step 2.1)

Digitised from Fig. 19d, embedded JPEG extracted at native 300 dpi (qtable mean 8.4,
blockiness 1.006 — effectively lossless), cropped and upscaled 4×, traced in
WebPlotDigitizer.

| Quantity | Value |
|---|---|
| Domain | quadrilateral, x = 0–268 m from toe, z = 200–365 m a.s.l. |
| **Cut face** | **31.06°**, x = 0–98 m, RMS 0.149 m over 16 pts |
| Toe | 271.13 m a.s.l. |
| Crest of cut | x = 102.1 m, z = 332.70 m a.s.l. |
| **Cut height** | **61.6 m** |
| Bench | x = 102–123 m, 0.40°, 21 m wide |
| Natural ground | x = 123–268 m, 7–22° |
| F1 fault | dip 81.4°, 86 m vertical extent, `x_f1(200) = 243.6`, `x_f1(358) = 267.6` |
| Mk / Mk_d divide | **x = 90.7 m**, vertical, measured from the figure tick (cols 697–700) |
| Panel V:H | 1.007 — no vertical exaggeration |

**Digitisation precision ±0.2 m**, verified four independent ways:
1. The 20/22/25° dashed rays fit to 20.63 / 22.50 / 25.07°
2. All three extrapolate to a common toe at 270.80–270.97 m a.s.l.
3. The F1 fault top lands on the ground surface to 0.03 m
4. The top-of-Tm contact, traced twice, agreed to 0.18 m mean absolute

**Daylight distances** (where each flattening ray emerges through existing ground):
20° at 191 m, 22° at 170 m, 25° at 136 m. These are the excavation cost behind each
F value and serve as an independent geometric cross-check.

---

## 4. Material properties

```python
# geometry.py
RHO    = {"Mk": 1519.0, "Mk_d": 1723.0, "Tm": 2650.0}   # kg/m3
K_S    = {"Mk": 1.0e-9, "Mk_d": 1.0e-9, "Tm": 3.13e-6}  # m/s
SIG_CI = {"Mk": 1.79e7, "Mk_d": 4.29e6, "Tm": 7.0e7}    # Pa
GSI    = {"Mk": 50,     "Mk_d": 45,     "Tm": 60}
M_I    = {"Mk": 4,      "Mk_d": 3,      "Tm": 12}
C_RES  = {"Mk": 4.4e3,  "Mk_d": 4.4e3,  "Tm": 4.4e3}    # Pa
PHI_RES= {"Mk": 15.4,   "Mk_d": 15.4,   "Tm": 15.4}     # deg

# boundaries.py
E_RM = {"Mk": 4.78e8, "Mk_d": 8.65e7, "Tm": 4.264e9}    # Pa
NU   = {"Mk": 0.28,   "Mk_d": 0.30,   "Tm": 0.25}
K0   = {"Mk": 0.389,  "Mk_d": 0.429,  "Tm": 0.333}      # nu/(1-nu)
```

**Two things the roadmap gets wrong here.** It uses a single K₀ = 0.39 throughout;
that is the *marl* value, and Tm is 87% of the domain by area and takes 0.333. And
Step 1.3 derives E and ν for marl, weak-zone marl, coal and tuffite but omits Tm
entirely, because it predates the identification of Tm as basement limestone.

**Tm values are literature estimates, not from the paper.** Ulusay et al. report no Tm
strength or stiffness because no critical surface passes through the basement.
σ_ci = 70 MPa (mid-range crystallized limestone), GSI = 60, mᵢ = 12 (Hoek,
limestone/marble), MR = 500, giving E_rm = 4264 MPa via Hoek–Diederichs. Flagged in
both files. **Verify with a σ_ci sweep of 40–100 MPa showing F is insensitive** — that
converts the gap into a documented, bounded assumption.

Note E_rm: Tm at 4264 MPa is **49× stiffer** than Mk_d at 86 MPa. Under load essentially
all strain localises in the weak zone, which is consistent with it governing F = 0.94.

---

## 5. Boundary conditions (Step 2.2), all verified

Six stratified segments, arc-length sampled (uniform sampling in x would under-resolve
the steep cut face by ~17%).

| Segment | Extent | Hydraulic | Mechanical |
|---|---|---|---|
| natural_ground | x 123→266 on `z_ground` | Neumann q·n = 5.56e-6 m/s | traction-free |
| bench | x 102→123, z ≈ 332.7 | Neumann, same | traction-free |
| cut_face | x 0→102 on `z_ground` | seepage face — see below | traction-free |
| pit_floor | x = 0, z 200→271.1 | no-flow | roller, u = 0 |
| base | z = 200, x 0→243.6 | no-flow | fixed, u = v = 0 |
| far_field_f1 | `x_f1(z)`, z 200→358 | Dirichlet ψ = −(z − 197) | roller, u = 0 |

**Three subtleties that were easy to get wrong:**

- **The flux is q·n, not q_z.** On the 31° face these differ by 14%. `outward_normal()`
  exists for this. Verified: mean vertical normal component on the cut face = 0.855
  against cos(31.06°) = 0.857.
- **The far field is a suction profile, not hydrostatic.** ψ runs −161 m at the top to
  −3.1 m at the base. Negative everywhere, because the domain is unsaturated.
- **The seepage face is not a Dirichlet condition.** The saturated portion is part of
  the solution. Correct statement is complementarity: ψ ≤ 0, q·n ≥ 0, ψ·(q·n) = 0.
  **Currently set to no-flow**, which is *exact* while the face is dry — which it is at
  t = 0. A Fischer–Burmeister implementation sits in `boundaries.py` behind
  `SEEPAGE_FACE_MODE`. Switch only after a working no-flow run shows the wetting front
  reaching the face; debugging complementarity and PINN convergence simultaneously is a
  bad position.

Also in `boundaries.py`: `body_force()` (ρ from `material_tag`),
`sigma_v_geostatic()` (layer-by-layer ρg integration, verified *exactly* against ρgh),
`sigma_h_geostatic()` (K₀σ_v, per-unit K₀).

---

## 6. Validation targets

From Fig. 19d, printed values, more reliable than the paper's rounded text figures:

| Case | F |
|---|---|
| **Initial project, 31° cut** | **0.94** ← primary |
| Flattened to 25° | 1.059 |
| Flattened to 22° | 1.342 |
| Flattened to 20° | 1.820 |

Four targets spanning 0.94–1.82, not one. A method that reproduces the whole trend is
far more convincing than one that hits a single number.

For Section 7 later: F = 1.19 initial, 0.744 and 0.707 shifting stages, 1.250 at 20°,
1.346 at 18°.

---

## 7. Data gaps, all flagged in code

**Tm strength and stiffness** — literature estimates. Close with a σ_ci 40–100 MPa
sensitivity sweep.

**Coal seam inflow** — the paper's text prints q₁ = 0.056 m³/day/m; the correct value
is **0.56**. Check: 0.56/√t summed over 30 days gives 5.368 m³/m against the paper's
stated 5.37; the 0.056 version gives 0.537. **Your Step 1.1 SI sheet carries the wrong
value.** Only matters for Section 7, but fix it there now. SI: 6.48e-6 m³/s/m.

**Suction cap** — open decision, see §8.

---

## 8. Step 2.3 — where to resume

The mechanical IC is **already done**: `sigma_v_geostatic` and `sigma_h_geostatic` in
`boundaries.py`, verified.

The seepage IC collapses to a single expression, because the whole domain is
unsaturated:

```python
def psi_initial(x, z):
    """t = 0 suction, hydrostatic w.r.t. the karstic table at 197 m a.s.l."""
    return -(np.asarray(z, float) - 197.0)
```

**One decision remains.** ψ₀ reaches −168 m at the crest — about 1.6 MPa, far into the
dry tail of any van Genuchten SWCC, where K(ψ) is near-singular and training will
struggle at initialisation.

- **Cap it**, e.g. `max(psi, -100)`, and document the cap. Kinder to training.
- **Keep it**, and accept θ ≈ θ_r over most of the domain at t = 0.

Either is defensible. Decide and record which.

**Also worth doing before Phase 3:** estimate the wetting-front penetration depth over
your intended simulation horizon. Through 10⁻⁹ m/s marl the front moves slowly. If it
never reaches the Mk_d/Tm contact, the lower two-thirds of the domain is doing nothing
and can be sampled coarsely — free speed in Phase 4.

---

## 9. Files in this package

```
HANDOFF.md                    <- this document
data/digitised/*.csv          <- the seven traced contacts + combined export
code/write_step22.sh          <- writes boundaries.py, 11_bc_checks.py, 12_bc_plot.py
code/write_step22_mech.sh     <- the mechanical extension (anchor may need adjusting)
docs/PINN_Thesis_60_15_Day_Workflow_corrected.docx
docs/Step_2.2_Boundary_Conditions_Directions.md
docs/Step_2.1_Ubuntu_Terminal_Walkthrough.md
```

`geometry.py` itself is **not** in this package — it lives in the git repo and is the
authoritative version. The CSVs here are the raw provenance from which it is built.

---

## 10. Resuming the environment

```bash
conda activate rosetta-ml
cd "/mnt/d/Books/Thesis/My thesis/step21_geometry"
python 09_checks.py && python 11_bc_checks.py && python 13_mech_checks.py
```

Three green blocks means everything survived. Suggested aliases:

```bash
cat >> ~/.bashrc << 'EOF'
export THESIS="/mnt/d/Books/Thesis/My thesis"
export STEP21="$THESIS/step21_geometry"
alias thesis='conda activate rosetta-ml && cd "$STEP21"'
alias tcheck='python 09_checks.py && python 11_bc_checks.py && python 13_mech_checks.py'
EOF
source ~/.bashrc
```

---

## 11. Outstanding risks

**No git remote.** Every commit is local. One drive failure loses the project, and the
lab PC cannot pull your code on Day 25. Five minutes: create a private GitHub repo,
then `git remote add origin <url> && git push -u origin main`. Authenticate with a
Personal Access Token, not your account password.

**Working directory is on `/mnt/d`** (Windows filesystem via 9p). Fine for this
workload — a handful of small files — but slow for anything with thousands of files.
If Phase 3 checkpointing becomes sluggish, move the training directory to `~`.

---

## 12. Process notes that saved time

**Measure, don't assume.** Every geometric claim in §3 was measured off pixels and
cross-checked. Two early estimates I made from category reasoning ("300 dpi JPEG →
fuzzy contacts → ±3 m") were wrong by an order of magnitude once measured (±0.2 m).

**A check that passes by testing nothing is worse than one that fails.** One acceptance
check initially reported PASS while examining an empty array. The `inner.sum() > 10`
guard now makes that failure mode loud.

**The overlay plot catches what numbers cannot.** A contact traced correctly but on the
wrong feature passes every numerical assertion. Two errors this session were found by
plotting digitised lines over the source figure — including one where 65 points had been
traced onto the wrong contact entirely.

**Python goes in files, not at the `$` prompt.** Several minutes were lost to pasting
Python into bash. Use `cat > file.py << 'PYEOF' ... PYEOF` as a single paste, or `nano`.
