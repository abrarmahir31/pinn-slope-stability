# rosetta-ml Environment — Setup Summary & Handoff

This file summarizes a completed environment setup so it can be continued in a new chat.
Copy this whole file (or the zip it comes in) into a new conversation to give full context.

---

## STATUS: COMPLETE AND VERIFIED

A full Python + PyRosetta environment is installed and working inside WSL2 (Ubuntu)
on a Windows machine. `verify_env.py` reports all packages `[ok]`.

---

## What was built

| Item | Detail |
|------|--------|
| Host OS | Windows (native) |
| Linux layer | WSL2 + Ubuntu (username: `abrar`, machine name shows as `WhiteShadow`) |
| conda | Installed via Miniforge **inside Ubuntu** (conda 26.3.2) |
| Environment name | `rosetta-ml` |
| Python | 3.10.20 |
| Project folder (Linux) | `~/rosetta-ml`  (i.e. `/home/abrar/rosetta-ml`) |
| Source files origin (Windows) | `C:\project`  → seen from Linux as `/mnt/c/project` |

### Installed packages (all verified `[ok]`)
- numpy 2.2.6
- scipy 1.15.2
- matplotlib 3.10.9
- torch 2.13.0  (CPU build — `PyTorch CUDA available: False`, which is correct)
- pyrosetta 2026.29+release.80a0635615  (Python 3.10, Ubuntu build)
- pyrosetta-installer 0.1.2

### Exact PyRosetta build (for reproducing on another machine, e.g. lab PC)
```
pyrosetta @ https://west.rosettacommons.org/pyrosetta/release/release/PyRosetta4.Release.python310.ubuntu.wheel/pyrosetta-0-cp310-cp310-linux_x86_64.whl#sha256=e79caa3878339417ff6e9c84ecbcad9a6e973dd1638593677e9ae3e875d5c4eb
pyrosetta-installer==0.1.2
```

---

## How to get back into the environment (every new session)

Open Ubuntu, then:
```bash
cd rosetta-ml
conda activate rosetta-ml
```
Prompt should show `(rosetta-ml)`. Then run scripts with `python yourscript.py`.

Quick sanity check:
```bash
python verify_env.py
```

Quick PyRosetta test:
```bash
python -c "import pyrosetta; pyrosetta.init(); print('works')"
```

---

## How it was set up (condensed step-by-step, for reference / redoing on lab PC)

1. **PowerShell didn't recognize `conda`** — Miniforge wasn't on PATH. Fixed by running
   `conda init powershell` from the Miniforge Prompt (catch-22: that command needs conda
   already recognized, so it must be run from the Miniforge Prompt first).
   NOTE: This ended up not mattering because the whole project moved into WSL2 instead.

2. **Installed WSL2 + Ubuntu.** `wsl --list --verbose` showed "no installed distributions",
   so ran:  `wsl --install -d Ubuntu`  (in PowerShell). Restarted, created Linux user
   `abrar` + password.

3. **Updated Ubuntu:**  `sudo apt update`

4. **Installed Miniforge INSIDE Ubuntu** (Windows conda does NOT carry over — separate world):
   ```bash
   curl -L -O "https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-$(uname)-$(uname -m).sh"
   bash Miniforge3-$(uname)-$(uname -m).sh
   ```
   Answered `yes` to license, Enter for location, `yes` to "Proceed with initialization?".
   Closed & reopened Ubuntu → prompt showed `(base)`.

5. **Copied project files from Windows into Ubuntu:**
   ```bash
   mkdir rosetta-ml && cd rosetta-ml
   cp /mnt/c/project/* .
   cp /mnt/c/project/.gitignore .
   ```

6. **Created the conda environment:**
   ```bash
   conda env create -f environment.yml
   conda activate rosetta-ml
   python verify_env.py     # numpy/scipy/matplotlib/torch all [ok]
   ```

7. **License:** PyRosetta downloads are covered by the PyRosetta Non-Commercial License
   (agreement-based). The recommended pip installer route does NOT require emailed
   credentials — no separate file to download from the Downloads page.

8. **Installed PyRosetta** (must be done with `rosetta-ml` ACTIVE, not base):
   ```bash
   pip install pyrosetta-installer
   mkdir -p ~/tmp
   TMPDIR=~/tmp python -c 'import pyrosetta_installer; pyrosetta_installer.install_pyrosetta()'
   ```
   ~1.7 GB download; auto-resumed after a connection timeout.

---

## Problems hit along the way (and fixes) — useful if redoing

- **`conda not recognized` in PowerShell** → run `conda init powershell` from Miniforge Prompt.
- **No Ubuntu app / `WSL_E_DISTRO_NOT_FOUND`** → `wsl --install -d Ubuntu`.
- **Typed the prompt text as a command** (`syntax error near unexpected token`) → only type
  the part AFTER the `$`. The `(base) abrar@...$` part is the prompt, not a command.
- **`ModuleNotFoundError: No module named 'pyrosetta_installer'`** → it was installed in
  `base` (Python 3.13) during the first failed attempt; must `pip install pyrosetta-installer`
  while `rosetta-ml` is ACTIVE.
- **`OSError(28) No space left on device` during download** → main disk was fine (951 GB free);
  redirected temp files with `TMPDIR=~/tmp` and cleared caches (`pip cache purge`).
  The `rm: cannot remove /tmp/systemd-private...` "Operation not permitted" messages are
  HARMLESS (protected system files in use).
- **verify_env.py showed pyrosetta `[--] not installed` even though it worked** → cosmetic bug
  in the script: it accessed `pyrosetta.__version__`, which this build doesn't expose, raising
  AttributeError. Fixed the line to use `getattr(pyrosetta, '__version__', 'installed')`.
  (This fix is already applied in the included verify_env.py.)

---

## VS Code note (optional — NOT required)

The terminal alone is fully sufficient. VS Code only adds editing comfort (autocomplete,
error underlines). If wanted later:
- Connect with the **WSL** extension, then run `code .` from `~/rosetta-ml`.
- The Python extension must be installed **into WSL** separately (button reads
  "Install in WSL: Ubuntu"). Without it, `Python: Select Interpreter` errors with
  `command 'python.setInterpreter' not found`.
- Then select interpreter: `/home/abrar/miniforge3/envs/rosetta-ml/bin/python`.

Terminal-only workflow: edit with `nano script.py` (save Ctrl+O, Enter; exit Ctrl+X),
run with `python script.py`.

---

## Files included in this package
- `SETUP_SUMMARY.md` — this file
- `environment.yml` — the conda recipe used
- `verify_env.py` — verification script (with the pyrosetta version fix applied)
- `README.md` — original project README
- `.gitignore` — original
